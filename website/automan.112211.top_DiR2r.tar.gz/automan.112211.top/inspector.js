// 存储当前高亮的元素和覆盖层
currentElement = null
overlayElement = null

// 创建覆盖元素
function createOverlay(rect) {
  const overlay = document.createElement('div')
  overlay.style.position = 'absolute'
  overlay.style.pointerEvents = 'none'
  overlay.style.boxSizing = 'border-box'
  overlay.style.zIndex = 999999
  overlay.style.top = rect.top + window.scrollY + 'px'
  overlay.style.left = rect.left + window.scrollX + 'px'
  overlay.style.width = rect.width + 'px'
  overlay.style.height = rect.height + 'px'
  overlay.style.backgroundColor = 'rgba(88, 129, 207, 0.6)'
  overlay.style.border = '1px dashed rgba(0, 0, 0, 0.6)'
  document.body.appendChild(overlay)
  return overlay
}

// 清除覆盖层
function clearOverlay() {
  overlayElement?.remove()
  overlayElement = null
}

// 高亮元素及其子元素
function highlightElement() {
  // 清除覆盖层
  clearOverlay()
  // 获取元素位置
  const rect = currentElement?.getBoundingClientRect()
  if (rect.width === 0 && rect.height === 0) return
  // 创建覆盖层
  overlayElement = createOverlay(rect)
}

// 鼠标进入事件监听通知浏览器获取焦点
document.addEventListener(
  'mouseenter',
  (e) => {
    if (window.inspectorEnabled) {
      e.preventDefault()
      e.stopPropagation()
    }
    console.log('window@@@mouseenter')
  },
  true
)

// 鼠标移动事件监听
document.addEventListener('mousemove', (e) => {
  if (window.inspectorEnabled) {
    // 获取鼠标下的元素
    const target = document.elementFromPoint(e.clientX, e.clientY)
    if (target && target !== currentElement) {
      currentElement = target
      highlightElement()
    }
  }
})

//监听按下时获取xpath和selector
document.addEventListener(
  'mousedown',
  (e) => {
    if (window.inspectorEnabled) {
      e.preventDefault()
      e.stopPropagation()
      //获取xpath
      const { xpath, selector } = getElementPaths(currentElement)
      console.log('xpath-@#@-selector:' + xpath + '-@#@-' + selector)
    }
  },
  true
)

//检查时阻挡默认行为
document.addEventListener(
  'click',
  (e) => {
    if (window.inspectorEnabled) {
      e.preventDefault()
      e.stopPropagation()
    }
  },
  true
)

// 创建一个新的 style 元素
const crosshair = document.createElement('style')
crosshair.textContent = ' * {cursor: crosshair !important}'
// 默认禁用检查模式
window.inspectorEnabled = false
document.activeElement.addEventListener('keydown', (e) => {
  if (e.ctrlKey || (e.metaKey && !window.inspectorEnabled)) {
    // document.activeElement.blur()
    window.inspectorEnabled = true
    //设置鼠标光标
    document.head.appendChild(crosshair)
    //高亮当前元素
    highlightElement()
  }
})

//监听按下Ctrl 或 Command
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey || (e.metaKey && !window.inspectorEnabled)) {
    window.inspectorEnabled = true
    //设置鼠标光标
    document.head.appendChild(crosshair)
    //高亮当前元素
    highlightElement()
  }
})
document.addEventListener('keyup', (e) => {
  //清除覆盖层
  clearOverlay()
  //禁用检查模式
  window.inspectorEnabled = false
  //移除鼠标光标
  document.head.removeChild(crosshair)
})

function getElementPaths(element) {
  const result = {
    xpath: '',
    selector: ''
  }

  if (!element || element.nodeType !== 1) return result

  // 处理 ID (优先级最高)
  if (element.id) {
    const escapedId = escapeValue(element.id)
    result.xpath = `//*[@id="${escapedId}"]`
    result.selector = `#${escapedId}`
    return result
  }

  // 处理 document 节点
  if (element === document) {
    result.xpath = '/html'
    result.selector = 'html'
    return result
  }

  // 获取元素的唯一标识信息
  const identity = getElementIdentity(element)

  result.selector = generateCSSSelector(element, identity)
  // 通过CSS选择器生成XPath
  result.xpath = css2xpath(result.selector)

  return result
}

// 获取元素的唯一标识信息
function getElementIdentity(element) {
  const identity = {
    id: null,
    uniqueClass: null,
    uniqueAttr: null,
    uniqueText: null,
    classCombo: null,
    attrCombo: null,
    index: null
  }

  // 检查ID (已经在主函数中处理过)

  // 检查唯一class
  identity.uniqueClass = getUniqueClass(element)

  // 检查唯一文本
  identity.uniqueText = getUniqueText(element)

  // 检查唯一class组合
  if (!identity.uniqueClass && !identity.uniqueAttr) {
    identity.classCombo = getUniqueClassCombination(element)
  }


  // 最后计算索引
  if (
    !identity.uniqueClass &&
    !identity.classCombo
  ) {
    identity.index = getStableElementIndex(element)
  }

  return identity
}

// 生成CSS选择器
function generateCSSSelector(element, identity) {
  const parts = []
  let current = element
  let currentIdentity = identity

  while (current && current !== document) {
    // 确保当前节点是元素节点
    if (current.nodeType !== 1) {
      current = current.parentNode
      currentIdentity = current ? getElementIdentity(current) : null
      continue
    }

    const tagName = current.tagName.toLowerCase()

    // 特殊处理HTML、BODY和HEAD标签
    if (tagName === 'html') {
      parts.unshift('html')
      break
    }

    if (tagName === 'body') {
      parts.unshift('body')
      current = current.parentNode
      currentIdentity = current ? getElementIdentity(current) : null
      continue
    }

    // 根据优先级构建CSS部分
    let cssPart = ''

    if (current.id) {
      cssPart = `#${escapeValue(current.id)}`
    } else if (currentIdentity.uniqueClass) {
      cssPart = `${tagName}.${escapeValue(currentIdentity.uniqueClass)}`
    } else if (currentIdentity.uniqueAttr) {
      cssPart = `${tagName}[${currentIdentity.uniqueAttr.name}="${escapeValue(currentIdentity.uniqueAttr.value)}"]`
    } else if (currentIdentity.classCombo) {
      const classSelectors = currentIdentity.classCombo
        .map((cls) => `.${escapeValue(cls)}`)
        .join('')
      cssPart = `${tagName}${classSelectors}`
    } else if (currentIdentity.attrCombo) {
      const attrSelectors = currentIdentity.attrCombo
        .map((attr) => `[${attr.name}="${escapeValue(attr.value)}"]`)
        .join('')
      cssPart = `${tagName}${attrSelectors}`
    } else {
      cssPart = `${tagName}:nth-of-type(${currentIdentity.index})`
    }

    parts.unshift(cssPart)

    // 如果当前部分是唯一的，停止向上查找
    const testSelector = parts.join(' > ')
    if (document.querySelectorAll(testSelector).length === 1) {
      break
    }

    current = current.parentNode
    currentIdentity = current ? getElementIdentity(current) : null
  }

  return parts.join(' > ')
}

// 检查元素的某个class是否唯一
function getUniqueClass(element) {
  if (!element || element.nodeType !== 1) return null
  if (!element.className || typeof element.className !== 'string') return null

  const classes = element.className
    .trim()
    .split(/\s+/)
    .filter((cls) => cls && !isDynamicClass(cls))

  for (const cls of classes) {
    if (isUniqueBySelector(`${element.tagName.toLowerCase()}.${escapeValue(cls)}`)) {
      return cls
    }
  }

  return null
}

// 检查元素的文本内容是否唯一
function getUniqueText(element) {
  if (!element || element.nodeType !== 1) return null

  const text = element.textContent.trim()
  if (!text) return null

  // 检查是否有精确匹配
  if (isUniqueByXPath(`//${element.tagName.toLowerCase()}[text()="${escapeValue(text)}"]`)) {
    return text
  }

  // 检查是否有包含匹配
  if (
    isUniqueByXPath(`//${element.tagName.toLowerCase()}[contains(text(), "${escapeValue(text)}")]`)
  ) {
    return text
  }

  return null
}

// 检查元素的某个class组合是否唯一
function getUniqueClassCombination(element) {
  if (!element || element.nodeType !== 1) return null
  if (!element.className || typeof element.className !== 'string') return null

  const classes = element.className
    .trim()
    .split(/\s+/)
    .filter((cls) => cls && !isDynamicClass(cls))

  // 尝试单个class
  for (const cls of classes) {
    if (isUniqueBySelector(`${element.tagName.toLowerCase()}.${escapeValue(cls)}`)) {
      return [cls]
    }
  }

  // 尝试两两组合
  for (let i = 0; i < classes.length; i++) {
    for (let j = i + 1; j < classes.length; j++) {
      const combo = [classes[i], classes[j]]
      const selector = combo.map((cls) => `.${escapeValue(cls)}`).join('')

      if (isUniqueBySelector(`${element.tagName.toLowerCase()}${selector}`)) {
        return combo
      }
    }
  }

  // 尝试三个组合
  for (let i = 0; i < classes.length; i++) {
    for (let j = i + 1; j < classes.length; j++) {
      for (let k = j + 1; k < classes.length; k++) {
        const combo = [classes[i], classes[j], classes[k]]
        const selector = combo.map((cls) => `.${escapeValue(cls)}`).join('')

        if (isUniqueBySelector(`${element.tagName.toLowerCase()}${selector}`)) {
          return combo
        }
      }
    }
  }

  return null
}

// 检查选择器是否唯一
function isUniqueBySelector(selector) {
  try {
    const matches = document.querySelectorAll(selector)
    return matches.length === 1
  } catch (e) {
    return false
  }
}

// 检查XPath是否唯一
function isUniqueByXPath(xpath) {
  try {
    const result = document.evaluate(
      xpath,
      document,
      null,
      XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
      null
    )
    return result.snapshotLength === 1
  } catch (e) {
    return false
  }
}

// 获取稳定的元素索引
function getStableElementIndex(element) {
  if (!element || element.nodeType !== 1) return 1

  let index = 1
  let sibling = element.previousElementSibling

  while (sibling) {
    if (sibling.tagName === element.tagName) {
      index++
    }
    sibling = sibling.previousElementSibling
  }

  return index
}

// 判断是否为动态class
function isDynamicClass(cls) {
  const dynamicPatterns = [
    /^ng-/,
    /^v-/,
    /^mat-/,
    /^md-/,
    /^el-/,
    /^ant-/,
    /^vue-/,
    /^react-/,
    /^_[a-z0-9]+$/,
    /^[0-9]+$/,
    /[0-9]+$/,
    /-[0-9a-f]{8,}$/
  ]

  return dynamicPatterns.some((pattern) => pattern.test(cls))
}

// 获取数组的所有组合
function getCombinations(arr, size) {
  const results = []

  function backtrack(start, current) {
    if (current.length === size) {
      results.push([...current])
      return
    }

    for (let i = start; i < arr.length; i++) {
      current.push(arr[i])
      backtrack(i + 1, current)
      current.pop()
    }
  }

  backtrack(0, [])
  return results
}

// 转义值以安全地用于XPath和CSS选择器
function escapeValue(value) {
  if (typeof value !== 'string') return ''

  // 转义XPath中的引号
  let escaped = value.replace(/'/g, "', \"'\", '")

  // 转义CSS选择器中的特殊字符
  escaped = escaped.replace(/[!"#$%&'()*+,./:;<=>?@[\]^`{|}~]/g, '\\$&')

  return escaped
}
